# Utility API

 - [(Abstract) Abstract Rate](@ref okapi::AbstractRate)
 - [(Abstract) Abstract Timer](@ref okapi::AbstractTimer)
 - [Logging](@ref okapi::Logger)
 - [Math Utilities](@ref mathUtil.hpp)
 - [Supplier](@ref okapi::Supplier)
 - [TimeUtil](@ref okapi::TimeUtil)
 - [TimeUtil Factory](@ref okapi::TimeUtilFactory)
 - [ConfigurableTimeUtil Factory](@ref okapi::ConfigurableTimeUtilFactory)
 - [Rate](@ref okapi::Rate)
 - [Timer](@ref okapi::Timer)
