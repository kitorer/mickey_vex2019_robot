#!/bin/bash
rm -rf html latex xml
./m.css/documentation/doxygen.py Doxyfile-mcss --debug
